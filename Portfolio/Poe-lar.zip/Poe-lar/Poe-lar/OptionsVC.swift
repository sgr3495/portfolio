//
//  OptionsVC.swift
//  Poe-lar
//
//  Created by igmstudent on 10/11/15.
//  Copyright © 2015 awesomedu0. All rights reserved.
//

import UIKit

class OptionsVC: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    //http://www.ioscreator.com/tutorials/uislider-tutorial-ios8-swift
    //UISlider Help
    var startFont:Float = 0.0
    var currentImage:UIImage!
    @IBOutlet weak var fontSizeLabel: UILabel!
    @IBOutlet weak var fontSizeSlider: UISlider!
    @IBOutlet weak var backgroundImageView: UIImageView!
    
    //MARK: - Action Methods -
    //checks for slider value after changing
    @IBAction func fontSliderValueChange(sender: AnyObject) {
        
        let currentValue:CGFloat = CGFloat(fontSizeSlider.value)
        print(currentValue)
        fontSizeLabel.font = fontSizeLabel.font.fontWithSize(currentValue)
    }
    
    //checks if change background was picked and opens up image picker
    @IBAction func changeBackgroundButton(sender: AnyObject) {
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        imagePicker.sourceType = .PhotoLibrary
        
        self.presentViewController(imagePicker, animated:true, completion:nil)
    }
    //function gets the image and dismisses the picker once done
    func imagePickerController(picker: UIImagePickerController!, didFinishPickingImage image: UIImage!, editingInfo: [NSObject : AnyObject]!) {
        backgroundImageView.image = image
        currentImage = image
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    
    //cancel button goes back if tapped
    @IBAction func cancelTapped(sender: AnyObject) {
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    //MARK: - Overrides -
    override func viewDidLoad() {
        super.viewDidLoad()
        
        fontSizeSlider.value = startFont
        fontSizeLabel.font = fontSizeLabel.font.fontWithSize(CGFloat(startFont))
        //check if there is a current background image
        if(currentImage !== nil)
        {
            backgroundImageView.image = currentImage
        }
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}
