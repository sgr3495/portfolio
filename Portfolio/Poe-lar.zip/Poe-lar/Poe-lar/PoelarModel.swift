//
//  PoelarModel.swift
//  Poe-lar
//
//  Created by igmstudent on 9/29/15.
//  Copyright © 2015 awesomedu0. All rights reserved.
//

import Foundation
import UIKit

class PoelarModel {
    
    var words:[String] = [ "s","the","of", "and", "a", "to", "in", "is", "you", "that", "it", "he", "for", "was", "on", "are", "as","night", "following", "picture", "being", "study", "second", "eyes", "soon", "times", "story", "boys", "since", "white", "days", "ever", "sure", "paper", "hard", "near", "sentence", "better", "best", "across", "during", "today", "others", "sure", "however", "means", "knew", "it", "is", "try", "told", "young", "miles", "sun", "ways", "thing", "whole", "hear", "example", "heard", "several", "change", "answer", "room", "sea", "against", "top", "turned", "learn", "point", "city", "toward", "five","other", "into", "has", "more", "her", "two", "like", "him", "see", "time", "could", "no", "make", "than", "first", "been", "its", "who", "now", "people", "my", "made", "over", "did", "down", "only", "way", "find", "use", "may", "long", "little", "very", "after", "words", "called", "just", "where", "most", "know", "get", "through", "back", "much", "go", "before", "good", "new", "write", "our", "used", "me", "man", "too", "any", "day", "same", "right", "look", "think", "also", "around", "another", "came"]
    
    var secondWords:[String] = [ "s","the","of", "and", "a", "to", "in", "is", "you", "that", "it", "he", "for", "was", "on", "are", "as","come", "work", "three", "word", "must", "because", "does", "part", "even", "place", "well", "such", "here", "take", "why", "things", "help", "put", "years", "different", "away", "again", "off", "went", "old", "number", "great", "tell", "men", "say", "small", "every", "found", "still", "between", "name", "should", "home", "big", "give", "air", "line", "set", "own", "under", "us", "end", "read", "last", "never", "left", "along", "while", "might", "next", "sound", "below", "saw", "both", "something", "thought", "few", "those", "always", "looked", "show", "large", "often", "together", "asked", "house", "do", "not", "world", "going", "want", "school", "important", "until", "form", "food", "keep", "children", "feet", "land", "side", "without", "boy", "once", "animals", "life", "enough", "took", "earth", "sometimes", "four", "head", "about", "kind", "began", "almost", "live", "page", "got", "need", "far", "let", "hand", "high", "year", "mother", "light", "part", "country", "father","y"]
    
    var thirdWords:[String] = ["s","the","of", "and", "a", "to", "in", "is", "you", "that", "it", "he", "for", "was", "on", "are", "as", "with", "his", "they", "at", "be", "this", "from", "I", "have", "or", "by", "one", "had", "not", "but", "what", "all", "were", "when", "we", "there", "can", "an", "your", "which", "their", "said", "if", "do", "will", "each", "about", "how", "up", "out", "them", "then", "she", "many", "some", "so", "these", "would", "using", "himself", "usually", "water", "earth", "fire", "air", "flying", "swimming", "control", "mind", "float", "super", "hero", "man", "woman", "building", "normal", "human", "burn", "monster", "tall", "short", "blast", "invisible", "rubber", "stone", "underwear", "vision", "laser", "green", "blue", "yellow", "pink", "red", "purple", "black", "white", "save", "destroy", "summon", "evil", "good", "y"]
    
    var zombieWords:[String] = ["s","abhorrent", " afraid", " Africa", " apparition", " appearance", " association", " berserk", " bloodcurdling", " brutal", " captivate", " Caribbean", " cemetery", " chimerical", " conjure", " copycat", " corpse", " creature", " creepy", " cringe", " curious", " curse", " dance", " dead", " death", " disappearance", " disembody", " disembowel", " disgusting", " disturbing", " dread", " dream", " dying", " eerie", " Egypt", " enemy", " escapade", " exhume", " fantasy", " folklore", " foul", " freakish", " fresh running water", " fringe group", " frozen", " games", " garb", " gasp", " generations", " ghastly", " ghost-like", " golem", " goose bumps", " goose flesh", " grave", " graveyard", " grotesque", " gruesome", " hair raising", " hallucination", " haunt", " heinous", " hideous", " history", " horrible", " hysteria","the","of", "and", "a", "to", "in", "is", "you", "that", "it", "he", "for", "was", "on", "are", "as","y"]
    
    var winterWords:[String] = ["s","the","of", "and", "a", "to", "in", "is", "you", "that", "it", "he", "for", "was", "on", "are", "as", "y", "winter", " season", " weather", " December", " January", " February", " scarf", " hat", " cap", " beanie", " mittens", " gloves", " sweater", " jacket", " coat", " vest", " shawl", " leggings", " boots", " pajamas", " robe", " slippers", " socks", " booties", " wool", " fleece", " heavy", " wrap", " bundle", " blanket", " comforter", " quilt", " patchwork", " skiing", " sledding", " skating", "  jingle", " shiver", " chill", " breath", " snowstorm", " blizzard", " rain", " sleet", " snow", " snowflakes", " snow bank", " snowball", " powder", " drift", " crust", " ice", " icicles", " crystals", " frost", " cold", " bitter", " windy", " nippy", " gusting", " frozen", " frigid", " sparkling", " slippery", " icy", " crunchy", " lacy", " delicate", " soft", " fluffy", " knee-deep", " powdery", " freezing", " melting", " blustery", " cloudy", " dreary", " drippy", " slushy", " rainy", " snowman", " shovel", " bells", " sled", " sleigh", " skis", " ice skates", " snowboard", " toboggan", " hill", " mountain", " pond", " rink", " forest", " woods", " creek", " river", " lane", " road", " holly", " pine", " cedar", " fir", " balsam", " scent", " boughs", " wreath", " trees", " branches", " bare", " dark", " silvery", " blue", " white", " gray", " brown", " clear", " piney", " bird feeder", " cardinal", " suet", " berries", " hibernate", " knit", " sew", " snuggle", " read", " book", " stories", " hearth", " smoke", " chimney", " coals", " flames", " fire", " fireplace", " blazing", " crackling", " glowing", " warm", " cozy", " toasty", " spiced", " spicy", " tea", " cider", " cocoa", " mug", " popcorn", " sugar", " vanilla", " spice", " ginger", " cinnamon", " nutmeg", " baking", " aroma", " waft"]
    
    var unusedThemes:[String] = ["House", "Nature", "Zombie", "Winter"]
    var randomWordList:[String] = []
    
    init () {
       
    }
    
    func randomWords(currentWordList:[String]) -> [String]{
        //clears old random words
        randomWordList = []
        
        //grabs random words from word list
        for (var i = 0; i < 20; i++) {
            let randomIndex = Int(arc4random_uniform(UInt32(currentWordList.count)))
            
            randomWordList.append(currentWordList[randomIndex])
        }
        
        //returns new wordList
        return randomWordList
    }

    
}