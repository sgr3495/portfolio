//
//  myFileFunctions.swift
//  Poe-lar
//
//  Created by igmstudent on 10/12/15.
//  Copyright © 2015 awesomedu0. All rights reserved.
//

import Foundation
import UIKit

func DocumentsDirectory()->String{
    return NSSearchPathForDirectoriesInDomains(NSSearchPathDirectory.DocumentDirectory, NSSearchPathDomainMask.UserDomainMask, true).first as String!
}

func TempDirectory() -> String{
    return NSTemporaryDirectory()
}

func FilePathInDocumentsDirectory(fileName:String) ->String{
    return (DocumentsDirectory() as NSString).stringByAppendingPathComponent(fileName)
}

func FileExists(path:String)->Bool{
    return NSFileManager.defaultManager().fileExistsAtPath(path)
}

func DeleteFileAtPath(path:String){
    do{
        try NSFileManager.defaultManager().removeItemAtPath(path)
        print("FILE: \(path) was deleted!")
    }catch{
        print("Error: \(error) - FOR FILE: \(path) - ")
    }
}

func ContentsOfDicectoryAtPath(path:String) ->[String]{
    let paths: [AnyObject]?
    do{
        paths = try NSFileManager.defaultManager().contentsOfDirectoryAtPath(path)
    } catch{
        print("Error: \(error)")
        return [String]() // return empty array of Strings on error
    }
    return paths as! [String]
}

func SaveImageAsPNG(image:UIImage, path:String) -> Bool{
    let pngData = UIImagePNGRepresentation(image)
    let result = pngData!.writeToFile(path, atomically:true)
    return result
}