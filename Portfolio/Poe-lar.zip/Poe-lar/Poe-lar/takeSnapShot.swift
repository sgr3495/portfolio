//
//  takeSnapShot.swift
//  Poe-lar
//
//  Created by igmstudent on 10/9/15.
//  Copyright © 2015 awesomedu0. All rights reserved.
//

import UIKit

extension UIView{
    func takeSnapshot() -> UIImage{
        UIGraphicsBeginImageContextWithOptions(self.bounds.size, false, UIScreen.mainScreen().scale)
        self.drawViewHierarchyInRect(self.bounds, afterScreenUpdates: true)
        let image = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext()
        return image;
    }
    
    func takeSnapShotAndClipFromBottom(amount:CGFloat) -> UIImage{
        let newRect = CGRectMake(self.bounds.origin.x, self.bounds.origin.y, self.bounds.width, self.bounds.height - amount)
        UIGraphicsBeginImageContextWithOptions(newRect.size, false, UIScreen.mainScreen().scale)
        self.drawViewHierarchyInRect(self.bounds, afterScreenUpdates: true)
        let image = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        return image;
    }
    
}
