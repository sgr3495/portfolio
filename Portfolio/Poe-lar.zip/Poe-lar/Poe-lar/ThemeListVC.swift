//
//  ThemeListVC.swift
//  Poe-lar
//
//  Created by igmstudent on 9/29/15.
//  Copyright © 2015 awesomedu0. All rights reserved.
//

import UIKit

class ThemeListVC: UITableViewController {
    
    var poeM:PoelarModel = PoelarModel()
    var themes:[(name:String, valueArray:[String])] = []
    var selectedTheme:[String] = []
    var selectedThemeName:String!
    
    //MARK: - View Overrides -
    override func viewDidLoad() {
        super.viewDidLoad()

        themes += [(name: "Random", valueArray: poeM.words)]
        themes += [(name: "House", valueArray: poeM.secondWords)]
        themes += [(name: "Nature", valueArray: poeM.thirdWords)]
        themes += [(name: "Zombie", valueArray: poeM.zombieWords)]
        themes += [(name: "Winter", valueArray: poeM.winterWords)]
    
        print("savedThemeName " + selectedThemeName)
        self.preferredContentSize = CGSizeMake(270, 250)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prefersStatusBarHidden() -> Bool {
        return true
    }

    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return (poeM.unusedThemes.count + 1)
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("themeIdentifier", forIndexPath: indexPath)
        let t = themes[indexPath.row]
        let name = t.name
        
        
        cell.textLabel?.text = name
        return cell
    }
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        selectedTheme = themes[indexPath.row].valueArray
        selectedThemeName = themes[indexPath.row].name
        //print(selectedTheme)
    }
    
    //MARK: - Action Methods - 
    @IBAction func cancelTapped(sender: AnyObject) {
        dismissViewControllerAnimated(true, completion: nil)
    }
    
}
