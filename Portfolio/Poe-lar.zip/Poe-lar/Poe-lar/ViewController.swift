//
//  ViewController.swift
//  Poe-lar
//
//  Created by igmstudent on 9/24/15.
//  Copyright © 2015 awesomedu0. All rights reserved.
//

import UIKit

// change class from viewController: UIViewController to class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    var poeM:PoelarModel = PoelarModel()
    var prevX:CGFloat = 40.0
    var prevW:CGFloat = 0.0
    var y:CGFloat = 20.0
    var first = true
    var device:String = ""
    let meGroup = UIMotionEffectGroup()
    var prevLabel:UILabel!
    var currentLabel:UILabel!
    var fontSize:CGFloat = 20.0
    var backgroundImage:UIImage!
    var currentTheme:String = "Random"
    let TOTAL_KEY = "totalKey"
    @IBOutlet weak var myImageView: UIImageView!
    
    //MAKE: - Label Creation -
    //creates and places all the labels on the view
    func placeWords(wordsArray:[String]) {
        let bounds = view.bounds
        let screenWidth = bounds.size.width

        for word in wordsArray {
            let l = UILabel()
            l.backgroundColor = UIColor.whiteColor()
            l.text = word + "  "
            l.textAlignment = NSTextAlignment.Center
            l.font = UIFont(name: "Avenir Medium", size: fontSize)
            l.sizeToFit()
            
            //set labels new x
            var newX:CGFloat
            let labelWidth = l.frame.size.width
            let labelHeight = l.frame.size.height
            
            // if the new x is beyond the screen width, reset to the beginning
            if(first) {
                newX = (labelWidth * 0.5) + 12.0
                y = y + labelHeight + 10.0
                prevW = labelWidth
                first = false
            } else {
                //previous X plus half the last labels width plus padding plus half the current labels width
                //Gets center x value of the label NOT top corner
                newX = prevX + (prevW * 0.5) + 12.0 + (labelWidth * 0.5)
                prevW = labelWidth
            }
            
            //if the new position is off the screen, then move to the next line
            if ((newX + (labelWidth * 0.5)) > (screenWidth - (labelWidth * 0.5))){
                newX = (labelWidth * 0.5) + 12.0
                y = y + labelHeight + 10.0
            }
            
            l.center = CGPointMake(newX, y)
            
            l.addMotionEffect(meGroup)
            view.addSubview(l)
            
            l.userInteractionEnabled = true
            let panGesture = UIPanGestureRecognizer(target: self, action: "doPanGesture:")
            
            let longPressGesture = UILongPressGestureRecognizer(target: self, action: "doLongPressGesture:")
            
            l.addGestureRecognizer(panGesture)
            l.addGestureRecognizer(longPressGesture)
            
            prevX = newX
            
        }
    }
    
    //MAKE: - Utility -
    
    //from supplied source, checks device type
    //stackoverflow.com/questions/24059327/detect-current-device-with-ui-user-interface-idiom-in-swift
    func checkDevice(){
        switch UIDevice.currentDevice().userInterfaceIdiom {
        case .Phone:
            // It's an iPhone
            device = "Phone"
            
        case .Pad:
            // It's an iPad
            
            device = "Tablet"
            
        case .Unspecified:
            // Uh, oh! What could it be?
            
            device = "Other"
        default: break
        }
    }
    
    //creates motion parallax effect to be added to labels later
    func createMotionParalax() {
        
        let leftRight = UIInterpolatingMotionEffect(keyPath: "center.x", type: UIInterpolatingMotionEffectType.TiltAlongHorizontalAxis)
        leftRight.minimumRelativeValue = -30.0
        leftRight.maximumRelativeValue = 30.0
        
        let topBottom = UIInterpolatingMotionEffect(keyPath: "center.y", type: UIInterpolatingMotionEffectType.TiltAlongVerticalAxis)
        topBottom.minimumRelativeValue = -30.0
        topBottom.maximumRelativeValue = 30.0
        
        meGroup.motionEffects = [leftRight, topBottom]
    }
    
    //MAKE: - Gestures -
    //dragging of words
    func doPanGesture(panGesture:UIPanGestureRecognizer){
        let label = panGesture.view as! UILabel
        let position = panGesture.locationInView(view)
        label.center = position
    }
    
    //makes words selected
    func doLongPressGesture(longPressGesture:UILongPressGestureRecognizer){
        currentLabel = longPressGesture.view as! UILabel
        if( longPressGesture.state == UIGestureRecognizerState.Began) {
            currentLabel.backgroundColor = UIColor.grayColor()
            if (prevLabel !== nil) {
                prevLabel.backgroundColor = UIColor.whiteColor()
            }
        }
        if( longPressGesture.state == UIGestureRecognizerState.Ended) {
            prevLabel = currentLabel
        }
    }
    
    
    //MAKE: - Segues -
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        //word set show and pass title
        if(segue.identifier == "ShowThemeSegue") {
            let themeVC = segue.destinationViewController.childViewControllers[0] as! ThemeListVC
            themeVC.title = "Choose Theme"
            themeVC.selectedThemeName = currentTheme
        }
        
        //options show and pass fontsize and backgroundImage
        if (segue.identifier == "ShowOptionsSegue") {
            let optionsVC = segue.destinationViewController.childViewControllers[0] as! OptionsVC
            optionsVC.title = "Options"
            optionsVC.startFont = Float(fontSize)
            optionsVC.currentImage = backgroundImage
        }
    }
    
    //MAKE: - Overrides -
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        view.backgroundColor = UIColor.init(red: 0.60, green: 0.90, blue: 1.00, alpha: 1.0)
        srandom(UInt32(time(nil)))
        checkDevice()
        if(device == "Tablet") {
            fontSize = 30.0
        } else {
            fontSize = 20.0
        }
        
        let startWords = poeM.randomWords(poeM.words)
        createMotionParalax()
        placeWords(startWords)
        
        //let closedBackground = UIImage(contentsOfFile: FilePathInDocumentsDirectory("mainview.png"))
        //backgroundImage = closedBackground
        
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "saveTheme", name: UIApplicationWillResignActiveNotification, object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "saveImage", name: UIApplicationWillResignActiveNotification, object: nil)
    
    }
    
    func saveTheme() {
        let defaults = NSUserDefaults.standardUserDefaults()
        defaults.setObject(currentTheme, forKey: TOTAL_KEY)
        defaults.synchronize()
        print("theme is called : \(currentTheme)")
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prefersStatusBarHidden() -> Bool {
        return true
    }
    
    func saveImage() {
        
        let image = view.takeSnapShotAndClipFromBottom(44)
        SaveImageAsPNG(image, path: FilePathInDocumentsDirectory("mainview.png"))
        UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil)
    }
    
    //MAKE: - Action Methods -
    
    @IBAction func unwindToMain(segue:UIStoryboardSegue) {
        if segue.identifier == "DoneTapped" {
            let themeVC = segue.sourceViewController as! ThemeListVC
            let theme = themeVC.selectedTheme
            currentTheme = themeVC.selectedThemeName
            //remove old labels
            for v in self.view.subviews {
                if v is UILabel {
                    v.removeFromSuperview()
                }
            }
            
            //create new random wordlist
            let newWords = poeM.randomWords(theme)
            //print(newWords)
            prevX = 40.0
            prevW = 0.0
            y = 20.0
            first = true
            placeWords(newWords)
            
        } else if segue.identifier == "OptionDoneTapped" {
            let optionsVC = segue.sourceViewController as! OptionsVC
            fontSize = CGFloat(optionsVC.fontSizeSlider.value)
            
            for v in self.view.subviews {
                if v is UILabel {
                    let label = v as! UILabel
                    label.font = label.font.fontWithSize(fontSize)
                    label.sizeToFit()
                }
            }
            
            backgroundImage = optionsVC.currentImage
            myImageView.image = backgroundImage
        }
    }
    
    //Code to delete a selected word from the view when the trash can is tapped
    @IBAction func deleteWord(sender: AnyObject) {
        for subview in self.view.subviews {
            if (currentLabel !== nil){
                if (subview is UILabel && subview == currentLabel){
                    let viewsToAnimate = [subview]
                    
                    UIView.performSystemAnimation(UISystemAnimation.Delete, onViews: viewsToAnimate, options: UIViewAnimationOptions.CurveLinear, animations: {
                        }, completion: { finished in
                            subview.removeFromSuperview()
                    })
                }
            }
        }
    }
    
    //Code for sharing application and saving image is included as one of the options
      @IBAction func sharedTapped(sender: UIBarButtonItem ) {
        
        let textToShare = "Poe-lar is best Magnetic Poetry App!"
        let igmWebsite = NSURL(string: "http://igm.rit.edu")
        let image = view.takeSnapShotAndClipFromBottom(44)
        //UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil)
        let objectsToShare:[AnyObject] = [textToShare, igmWebsite!, image]
        let activityVC = UIActivityViewController(activityItems: objectsToShare, applicationActivities: nil)
        //self.presentViewController(activityVC, animated: true, completion: nil)
        
        if let pop = activityVC.popoverPresentationController {
            pop.sourceView = view
        }
        
        self.presentViewController(activityVC, animated: true, completion: nil)
        
    }

}

