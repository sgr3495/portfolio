//
//  EventManager.swift
//  Data Downloader
//
//  Created by jefferson on 10/22/15.
//  Copyright © 2015 tony. All rights reserved.
//

import Foundation

class EventManager {
     var events:[Event]
     var favorites:[Event]
    static let sharedInstance = EventManager()
    
    init(){
        events = [Event]()
        favorites = [Event]()
    }
    
    func getEvents()->[Event]{
        return events
    }
    
    func getFavorites()->[Event]{
        return favorites
    }
    
    func setEvents(argEvents:[Event]){
        events = argEvents
    }
    
    func addEvent(event:Event){
        events.append(event)
    }
    
    func removeEvent(event:Event){
        events.removeObject(event)
    }
    
    func removeFavorite(event:Event){
        favorites.removeObject(event)
    }
    
    func removeAllEvents(){
        events.removeAll()
    }
    
    func addFavorite(event:Event){
        favorites.append(event)
    }
    
    func remvoeFavorite(event:Event){
        favorites.removeObject(event)
    }
    
}

//singleton
let sharedEventManager = EventManager()
