//
//  SearchVC.swift
//  SeachEvent
//
//  Created by igmstudent on 11/4/15.
//  Copyright © 2015 Shawn Ribaudo. All rights reserved.
//

import UIKit

class SearchVC: UITableViewController, UISearchBarDelegate {
    
    //var e :EventManager = EventManager()
    var e = EventManager.sharedInstance
    let mySimpleCell = "SimpleCell"
    
    var tableData = [String]()
    var urlData = [String]()
    var tableDataStartTime = [String]()
    var longitudeData = [String]()
    var latitudeData = [String]()
    var descriptionData = [String]()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
        
        //searchEvents("wichita")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        if(e.getEvents().count == 0){
            return 1
        }
        else{
            return e.getEvents().count
        }
        
    }

    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier(mySimpleCell, forIndexPath: indexPath)
        cell.accessoryType = UITableViewCellAccessoryType.DisclosureIndicator
        //configure the cell...
        
        var event = e.getEvents()
        
        if(e.getEvents().count>0){
            let eventRow = event[indexPath.row]
            cell.textLabel?.text = eventRow.title
            cell.detailTextLabel?.text = eventRow.start_time
        }
       
        if(e.getEvents().count == 0){
            cell.textLabel?.text = "No result found"
            cell.detailTextLabel?.text = "N/A"
        }
        
        //let pathToFile = FilePathInDocumentsDirectory("allEvents.archive")
       // let success = NSKeyedArchiver.archiveRootObject(event, toFile: pathToFile)
        //print("Saved = \(success) to \(pathToFile)")

        return cell
    }
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let detailVC: DetailVC = storyboard!.instantiateViewControllerWithIdentifier("DetailVC") as! DetailVC

        var event = e.getEvents()
        if e.getEvents().count>0{
        let eventRow = event[indexPath.row]

        detailVC.event = eventRow
        
        self.navigationController?.pushViewController(detailVC, animated: true)
        }
    }
    
    /*
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            // Delete the row from the data source
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        } else if editingStyle == .Insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    func searchEvents(location:String){
        
        tableView.contentInset = UIEdgeInsets(top: 64, left: 0, bottom: 0, right: 0)
        
        // Do any additional setup after loading the view, typically from a nib.
        print("on main thread in viewDidLoad() = \(NSThread.isMainThread())")
        
        
        let config = NSURLSessionConfiguration.defaultSessionConfiguration()
        let session = NSURLSession(configuration: config)
        let url = NSURL(string: "http://api.eventful.com/json/events/search?location=\(location)&app_key=25m6LVxkzJGpZMkg")
        
        let dataTask = session.dataTaskWithURL(url!, completionHandler:{(data:NSData?, response:NSURLResponse?, error:NSError?) -> Void in
            
            print("error = \(error)")
            //do something with the data
            if let data = data{
                print("response = \(response)")
                //let s = NSString(data: data, encoding: NSUTF8StringEncoding)
                // print("s = \(s)")
                do{
                    let json = try NSJSONSerialization.JSONObjectWithData(data, options: NSJSONReadingOptions(rawValue: 0 )) as! [String:AnyObject]
                    print("json=\(json)")
                    // all the code in this completion handler is running
                    //on a background thread. Dont beleive me? here's
                    //some code to prove it:
                    print("on main thread in callback() = \(NSThread.isMainThread())")
                    
                    //now parse the JSON
                    //does top level "events" key exist?
                    if let d1 = json["events"]{
                        //if d1 is not a dictionary, bail out
                        if !(d1 is [String:AnyObject]){
                            print("d1 is not a dictionary - No results found")
                            UIApplication.sharedApplication().networkActivityIndicatorVisible = false
                            return
                        }
                        //does "event" key exist?
                        if let a1 = d1["event"]{
                            //if a1 is not an array of dictionaries, bail out
                            if !(a1 is [[String:AnyObject]]){
                                print("a1 is not an array of dictionaries - No results found")
                                return
                            }
                            //loop through array of dictionaries
                            for d2 in a1 as! [[String:AnyObject]]{
                                var string = ""
                                var startDateString = ""
                                var longitudeString = ""
                                var latitudeString = ""
                                var urlString = ""
                                var descriptionArg = ""
                                
                                // is there a title key in the dictionary?
                                if let title = d2["title"] as! String?{
                                    string += title
                                }
                                
                                //is there a startDate key in the dictionary?
                                if let startDate = d2["start_time"] as! String?{
                                    startDateString += startDate
                                }
                                
                                //is there a longitude key in the dictionary?
                                if let longitude = d2["longitude"] as! String?{
                                    longitudeString += longitude
                                }
                                
                                //is there a latitude key in the dictionary?
                                if let latitude = d2["latitude"] as! String?{
                                    latitudeString += latitude
                                }
                                
                                //is there a url key in the dictionary?
                                if let url = d2["venue_url"] as! String?{
                                    urlString += url
                                }
                                /*
                                //is there a description key in the dictionary?
                                if let description = d2["description"] as? String?{
                                    descriptionString += description
                                }
                                */
                                if (d2["description"] is String){
                                    if let description = d2["description"] as! String?{
                                            descriptionArg = description
                                        } else {
                                            descriptionArg = "No Description Found"
                                        }
                                    }else{
                                        descriptionArg = "No Description Found"
                                    }
                                
                                //add event to our table data
                                self.e.addEvent(Event(title: string, start_time: startDateString, descript: descriptionArg, url: urlString, lat: (latitudeString as NSString).floatValue, lng: (longitudeString as NSString).floatValue))
                                //EventManager.sharedInstance.addEvent(Event(title: string, start_time: startDateString, descript: descriptionArg, url: urlString, lat: (latitudeString as NSString).floatValue, lng: (longitudeString as NSString).floatValue))
                            }
                        }
                    }
                    
                    //all done? call back to main thread
                    dispatch_async(dispatch_get_main_queue(), {
                        //update the UI
                        self.tableView.reloadData()
                        print("on main thread in dispatch_async = \(NSThread.isMainThread())")
                        UIApplication.sharedApplication().networkActivityIndicatorVisible = false
                    })
                }catch{
                    print(error)
                }
            }else{

                print("No data!")
            }
        })
        
        dataTask.resume()
        
        
        
    }
    
    func searchBarSearchButtonClicked(searchBar: UISearchBar) {
        //did the user type something in?
        let text = searchBar.text
        if text == nil || text?.characters.count == 0{
            return
        }
        
        // do URL encoding - add %20 for spaces
        if let searchTerm = text?.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLQueryAllowedCharacterSet()){
            
            //empty the table data
            e.removeAllEvents()
           // EventManager.sharedInstance.removeAllEvents()
        
            //reload table (which clears it)
            tableView.reloadData()
            
            UIApplication.sharedApplication().networkActivityIndicatorVisible = true
            
            //search the EventFulAPI
            searchEvents(searchTerm)
            
        }
    }
    
    func searchBarCancelButtonClicked(searchBar: UISearchBar) {
        
        searchBar.resignFirstResponder()
    }
    
    

}
