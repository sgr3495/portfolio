//
//  Array+Methods.swift
//  Data Downloader
//
//  Created by jefferson on 10/22/15.
//  Copyright © 2015 tony. All rights reserved.
//

import Foundation

// Swift arrays don't have a native removeObject method

// http://stackoverflow.com/questions/24938948/array-extension-to-remove-object-by-value
extension Array where Element : Equatable {
    // Remove first collection element that is equal to the given `object`:
    mutating func removeObject(object : Generator.Element) {
        if let index = self.indexOf(object) {
            self.removeAtIndex(index)
        }
    }
}

