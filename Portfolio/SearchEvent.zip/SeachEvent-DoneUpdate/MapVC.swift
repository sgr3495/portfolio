//
//  MapDetailVC.swift
//  SeachEvent
//
//  Created by igmstudent on 11/8/15.
//  Copyright © 2015 Shawn Ribaudo. All rights reserved.
//

import UIKit
import MapKit

class MapVC: UIViewController, MKMapViewDelegate {
    
    @IBOutlet var mapView: MKMapView!
    //var event: Event?
    var e:EventManager = EventManager()
    var event:[Event] = []
    
    let METERS_PER_MILE: Double = 1609.344
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        self.navigationItem.rightBarButtonItem = self.editButtonItem()
        
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        event = EventManager.sharedInstance.getEvents()
        print(event)
        
        for (var i = 0; i < event.count; i++){
            title = event[i].title
            mapView.delegate = self
            
            let location = Event(title: (event[i].title)!, start_time: "", descript: (event[i].subtitle)!, url: "", lat: (event[i].lat)!, lng: (event[i].lng)!)
            
            mapView.addAnnotation(location)
            let myRegion = MKCoordinateRegionMakeWithDistance(location.coordinate,METERS_PER_MILE * 100, METERS_PER_MILE * 100)
            mapView.setRegion(myRegion, animated: true)
            mapView.selectAnnotation(location, animated: true)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
    // Get the new view controller using segue.destinationViewController.
    // Pass the selected object to the new view controller.
    }
    */
    
    
}
