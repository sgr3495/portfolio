//
//  Event.swift
//  Data Downloader
//
//  Created by jefferson on 10/20/15.
//  Copyright © 2015 tony. All rights reserved.
//
import MapKit
import CoreLocation
import Foundation

public class Event:NSObject,MKAnnotation {
    private var eventTitle:String
    public var start_time:String
    public var descript:String?
    public var url:String?
    public var coordinate:CLLocationCoordinate2D
    public var latitude:Float?
    public var longitude:Float?
    
    init(title:String,start_time:String){
        self.eventTitle = title
        self.start_time = start_time
        self.coordinate = CLLocationCoordinate2DMake(0.0, 0.0)
        super.init()
    }
    
    init(title:String,start_time:String,descript:String,url:String,lat:Float,lng:Float){
        self.eventTitle = title
        self.start_time = start_time
        self.descript = descript
        self.url = url
        self.longitude = lng
        self.latitude = lat
        self.coordinate = CLLocationCoordinate2D(latitude: CLLocationDegrees(lat), longitude: CLLocationDegrees(lng))
        super.init()
    }
    
    
    public var title:String?{
        return eventTitle
    }
    
    public var subtitle:String?{
        return descript
    }
    
    public var lat:Float?{
        return latitude
    }
    
    public var lng:Float?{
        return longitude
    }
    
    public override var description : String {
        return "\(title!) : (\(coordinate))\n\n"
    }
    
    public func encodeWithCoder(aCoder: NSCoder) {
        print("\(__FUNCTION__) called.")
        aCoder.encodeObject(eventTitle, forKey: "eventTitle")
        //to make life easier, save our coordinate components separately
        aCoder.encodeDouble(coordinate.latitude, forKey: "latitude")
        aCoder.encodeDouble(coordinate.longitude, forKey: "longitude")
        
        aCoder.encodeObject(start_time, forKey: "start_time")
        aCoder.encodeObject(descript, forKey: "description")
        aCoder.encodeObject(url, forKey: "url")
    }
    
}
